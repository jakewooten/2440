package solution;
/**
 * This is the feral cat class.
 * FeralCat.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class FeralCat extends Feline
{
    /**
     * @param myZoo
     * this is myZoo
     * @param name
     * this is name
     */
    public FeralCat(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("meow...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        System.out.println("pick...");
        setHungerLevel(getHungerLevel() - 3);
    }
}

