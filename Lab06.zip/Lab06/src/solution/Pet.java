package solution;
/**
 * this is the pet class.
 * Pet.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public interface Pet
{
    /**
     * this is the play method.
     */
    public void play();
    /**
     * this is the beFriendly method.
     */
    public void beFriendly();
}
