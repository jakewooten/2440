package solution;
/**
 * this is the wolf class.
 * Wolf.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Wolf extends Canine
{
    /**
     * @param myZoo 
     * this is myZoo
     * @param name 
     * this is name
     */
    public Wolf(Zoo myZoo, String name)
    {
       super(myZoo, name); 
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("growl...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        System.out.println("rip with teeth...");
        setHungerLevel(getHungerLevel() - 2);
    }
}
