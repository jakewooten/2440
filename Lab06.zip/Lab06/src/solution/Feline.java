package solution;
/**
 * this is the feline class.
 * Feline.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public abstract class Feline extends Animal
{
    /**
     * @param myZoo 
     * this is myzoo 
     * @param name 
     * this is name 
     */
    public Feline(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the roam method.
     */
    public void roam()
    {
        System.out.println("felines like to roam alone...");
        setHungerLevel(getHungerLevel() + 1);
    }
}
