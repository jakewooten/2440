package solution;
/**
 * this is the canine class.
 * Canine.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public abstract class Canine extends Animal
{
    /**
     * @param myZoo 
     * this is myZoo
     * @param name 
     * this is name
     */
    public Canine(Zoo myZoo, String name)
    {
       super(myZoo, name); 
    }
    /**
     * this is the roam method.
     */
    public void roam()
    {
        super.setHungerLevel(getHungerLevel() + 1);
        System.out.println("like canines roam in packs...");
    }
}
