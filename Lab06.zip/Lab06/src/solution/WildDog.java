package solution;
/**
 * this is the wildDog class.
 * WildDog.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class WildDog extends Canine
{
    /**
     * @param myZoo 
     * this is myzoo
     * @param name 
     * this is name
     */
    public WildDog(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("bark...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        System.out.println("slop...");
        setHungerLevel(getHungerLevel() - 3);
    }
}
