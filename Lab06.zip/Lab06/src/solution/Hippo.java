package solution;
/**
 * this is the hippo class.
 * Hippo.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Hippo extends Animal
{
    /**
     * @param myZoo 
     * this is myZoo
     * @param name 
     * this is name
     */
    public Hippo(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("blub...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        super.setHungerLevel(getHungerLevel() - 1);
        System.out.println("slurp...");
    }

}
