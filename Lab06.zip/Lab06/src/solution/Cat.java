package solution;
/**
 * this is the cat class.
 * Cat.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Cat extends Feline implements Pet
{
    /**
     * @param myZoo
     * this is myZoo 
     * @param name
     * this is name
     */
    public Cat(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("meow...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        System.out.println("pick...");
        setHungerLevel(getHungerLevel() - 3);
    }
    /**
     * this is the play method.
     */
    public void play()
    {
        System.out.println("frolic...");
    }
    /**
     * this is the beFriendly method.
     */
    public void beFriendly()
    {
        System.out.println("purr...");
    }
}
