package solution;
/**
 * this is the dog class.
 * Dog.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Dog extends Canine implements Pet
{
    /**
     * @param myZoo 
     * this is myZoo
     * @param name 
     * this is name
     */
    public Dog(Zoo myZoo, String name)
    {
       super(myZoo, name); 
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("bark...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        super.setHungerLevel(getHungerLevel() - 3);
        System.out.println("slop..."); 
    }
    /**
     * this is the play method.
     */
    public void play()
    {
       // System.out.println("...");
    }
    /**
     * this is the beFriendly method.
     */
    public void beFriendly()
    {
        //System.out.println("...");
    }
}
