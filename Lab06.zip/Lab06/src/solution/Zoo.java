package solution;
import java.util.ArrayList;
/**
 * this is the zoo class.
 * Zoo.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Zoo implements AnimalLocation
{
    private String name;
    private double latitude;
    private double longitude;
    private ArrayList<Animal> zooAnimals;
    /**
     * @param name 
     * this is name
     * @param lat 
     * this is lat
     * @param lon 
     * this is lon
     */
    public Zoo(String name, double lat, double lon)
    {
        zooAnimals = new ArrayList<Animal>();
        this.name = name;
        latitude = lat;
        longitude = lon;
    }
    /**
     * @return latitude 
     * this is latitude
     */
    public double getLatitude()
    {
        return  latitude;
    }
    /**
     * @return longitude
     * this is longitude 
     */
    public double getLongitude()
    {
        return longitude;
    }
    /**
     * @return name
     * this is name 
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name 
     * this is name
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     * @return zooAnimals.size() 
     * this is zooAnimals.size()
     */
    public int getNumOfAnimals()
    {
        return zooAnimals.size();
    }
    /**
     * @param animal 
     * this is anima
     */
    public void addAnimal(Animal animal)
    {
        zooAnimals.add(animal);
    }
    /**
     * this is the testAnimals method.
     */
    public void testAnimals()
    {
        System.out.println(name + "\n" + getLatitude()
             + "\n" + getLongitude() + "\n" + getNumOfAnimals());
        
        for (Animal an : zooAnimals)
        {
            if (an instanceof Pet)
            {
                Pet p = (Pet) an;
                p.play();
                p.beFriendly();
            }
            an.sleep();
            an.makeNoise();
            an.eat();
            an.roam();
        }

    }
    /**
     * @param args 
     * this is args
     */
    public static void main(String[] args)
    {
        Zoo z = new Zoo("Zooy", 4, 5);
        
        //create an animal of each type
        Canine doggy = new Dog(z, "Doggy");
        Canine wolfy = new Wolf(z, "Wolfy");
        Feline catty = new Cat(z, "Catty");
        Animal hippoy = new Hippo(z, "Hippoy");
        Canine coyotey = new Coyote(z, "Coyotey");
        Feline liony = new Lion(z, "Liony");
        Feline feralCatty = new FeralCat(z, "FeralCatty");
        Canine wildDoggy = new WildDog(z, "WildDoggy");

        //add them to the ArrayList
        z.zooAnimals.add(doggy);
        z.zooAnimals.add(wolfy);
        z.zooAnimals.add(catty);
        z.zooAnimals.add(hippoy);
        z.zooAnimals.add(coyotey);
        z.zooAnimals.add(liony);
        z.zooAnimals.add(feralCatty);
        z.zooAnimals.add(wildDoggy);



    }
}
