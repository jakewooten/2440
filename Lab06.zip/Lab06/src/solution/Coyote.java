package solution;
/**
 * this is the coyote class.
 * Coyote.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public class Coyote extends Canine
{
    /**
     * @param myZoo 
     * this is myzoo
     * @param name 
     * this is name
     */
    public Coyote(Zoo myZoo, String name)
    {
        super(myZoo, name);
    }
    /**
     * this is the makeNoise method.
     */
    public void makeNoise()
    {
        System.out.println("howl...");
    }
    /**
     * this is the eat method.
     */
    public void eat()
    {
        System.out.println("gnaws...");
        setHungerLevel(getHungerLevel() - 2);
    }
}
