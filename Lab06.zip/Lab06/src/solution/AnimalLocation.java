package solution;
/**
 * this is the animal location class.
 * AnimalLocation.java
 * @author Jake Wooten
 * @version 10-9-18
 */
public interface AnimalLocation
{
    /**
     * @return name
     * this returns name
     */
    public String getName();
    /**
     * @param locName
     * this is locName
     */
    public void setName(String locName);
    /**
     * @return animals
     */
    public int getNumOfAnimals();
}
