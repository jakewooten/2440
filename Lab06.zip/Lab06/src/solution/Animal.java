package solution;
/**
 * Sentence.
 * Animal.java
 * @author Jake Wooten 
 * @version 10-9-18 
 */
abstract public class Animal
{
    private String name;
    private Zoo zoo;
    private int hungerLevel;
 
    /**
     * @param myZoo
     * this is the zoo object
     * @param anName
     * this is the an name
     */
    public Animal(Zoo myZoo, String anName)
    {
        zoo = myZoo;
        name = anName;
    }
    /**
     * @return hungerLevel 
     */
    public int getHungerLevel()
    {
        return hungerLevel;
    }

    /**
     * @param hunger
     * this is hunger 
     */
    public void setHungerLevel(int hunger)
    {
        if (hunger >= 0 &&  hunger <= 10)
        {
            hungerLevel = hunger;
        }
        else if (hunger < 0)
        {
            hungerLevel = 0;
        }
        else if (hunger > 10)
        {
            hungerLevel = 10;
        }
    }
    /**
     * @return name 
     * this is name
     */
    public String getName()
    {
        return name;
    }
    /**
     * @param name
     * this is name 
     */
    public void setName(String name)
    {
        this.name = name;
    }
    /**
     *this is the sleep method.
     */
    public void sleep()
    {
        System.out.println("sleeping...");
        hungerLevel = 10;
    }
    /**
     * this is the roam method.
     */
    public void roam()
    {
        System.out.println("moving around...");
        setHungerLevel(getHungerLevel() + 1);
    }
    /**
     * this is the make noise makeNoise.
     */
    public abstract void makeNoise();
    /**
     * this is the eat method.
     */
    public abstract void eat();
}
